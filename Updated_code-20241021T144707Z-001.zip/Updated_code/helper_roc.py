import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# Constants
trialsPerPhase = 16
totalPhase = 4

family_code = {
    "SAUROPODOMORPHA": 1,
    "STYRACOSTERNA": 2,
    "THEROPODA": 3,
    "ELASMARIA": 4
}

rating_code = {
    "VERY UNCERTAIN": 0,
    "UNCERTAIN": 1,
    "CERTAIN": 2,
    "VERY CERTAIN": 3
}


def getQualifiedCandList(flag, qualified_cand_file):
    try:
        # flag 1 -> Dino 2 -> Sym

        file1 = open(qualified_cand_file, "r")

        cand = []

        postfix = ''

        if flag == 2:
            postfix = '-Symspan.txt'
        else:
            postfix = '-Dino.csv'

        for f in file1.readlines():
            name = f.split('\n')[0]
            if name == 'FI05G1' or name == 'JT07R8' or name == 'MN07N2' or name == 'LE07K2' or name == 'RS08K7':
                continue
            name += postfix
            cand.append(name)

        file1.close()
        print('Success')
        return cand
    except Exception as e:
        print('Failed -> ', e)


def getMatchMisMatchFreqForEachStudentPerPhase(dino_files, dino_path):
    try:
        # 4 -> Very Certaian
        output_data_complete = {
            "1-4-Yes": [],
            "1-3-Yes": [],
            "1-2-Yes": [],
            "1-1-Yes": [],
            "1-1-No": [],
            "1-2-No": [],
            "1-3-No": [],
            "1-4-No": [],

            "2-4-Yes": [],
            "2-3-Yes": [],
            "2-2-Yes": [],
            "2-1-Yes": [],
            "2-1-No": [],
            "2-2-No": [],
            "2-3-No": [],
            "2-4-No": [],

            "3-4-Yes": [],
            "3-3-Yes": [],
            "3-2-Yes": [],
            "3-1-Yes": [],
            "3-1-No": [],
            "3-2-No": [],
            "3-3-No": [],
            "3-4-No": [],

            "4-4-Yes": [],
            "4-3-Yes": [],
            "4-2-Yes": [],
            "4-1-Yes": [],
            "4-1-No": [],
            "4-2-No": [],
            "4-3-No": [],
            "4-4-No": [],
        }

        output_table_complete = pd.DataFrame(output_data_complete)

        for csv in dino_files:
            df = pd.read_csv(dino_path + csv)

            df = df[['choice_label', 'response_cat', 'button_pressed_conf']]

            # Clean Dataframe
            df.dropna(inplace=True)
            df.reset_index(drop=True, inplace=True)

            sId = csv.split('-')[0]

            # Convert String to uppercase
            df['choice_label'] = df['choice_label'].str.upper()
            df['response_cat'] = df['response_cat'].str.upper()

            match = []
            mismatch = []

            for phase in range(totalPhase):
                startIndex = phase * trialsPerPhase
                endIndex = (phase + 1) * trialsPerPhase

                sub_df = df[startIndex:endIndex]
                sub_df.reset_index(drop=True, inplace=True)

                hit_very_uncertain = len(sub_df[(sub_df['button_pressed_conf'] == 0) & (
                    sub_df['response_cat'] == 'HIT') & (sub_df['choice_label'] == 'YES')])
                hit_uncertain = len(sub_df[(sub_df['button_pressed_conf'] == 1) & (
                    sub_df['response_cat'] == 'HIT') & (sub_df['choice_label'] == 'YES')])
                hit_certain = len(sub_df[(sub_df['button_pressed_conf'] == 2) & (
                    sub_df['response_cat'] == 'HIT') & (sub_df['choice_label'] == 'YES')])
                hit_very_certain = len(sub_df[(sub_df['button_pressed_conf'] == 3) & (
                    sub_df['response_cat'] == 'HIT') & (sub_df['choice_label'] == 'YES')])

                fa_very_uncertain = len(sub_df[(sub_df['button_pressed_conf'] == 0) & (
                    sub_df['response_cat'] == 'FA') & (sub_df['choice_label'] == 'YES')])
                fa_uncertain = len(sub_df[(sub_df['button_pressed_conf'] == 1) & (
                    sub_df['response_cat'] == 'FA') & (sub_df['choice_label'] == 'YES')])
                fa_certain = len(sub_df[(sub_df['button_pressed_conf'] == 2) & (
                    sub_df['response_cat'] == 'FA') & (sub_df['choice_label'] == 'YES')])
                fa_very_certain = len(sub_df[(sub_df['button_pressed_conf'] == 3) & (
                    sub_df['response_cat'] == 'FA') & (sub_df['choice_label'] == 'YES')])

                miss_very_uncertain = len(sub_df[(sub_df['button_pressed_conf'] == 0) & (
                    sub_df['response_cat'] == 'MISS') & (sub_df['choice_label'] == 'NO')])
                miss_uncertain = len(sub_df[(sub_df['button_pressed_conf'] == 1) & (
                    sub_df['response_cat'] == 'MISS') & (sub_df['choice_label'] == 'NO')])
                miss_certain = len(sub_df[(sub_df['button_pressed_conf'] == 2) & (
                    sub_df['response_cat'] == 'MISS') & (sub_df['choice_label'] == 'NO')])
                miss_very_certain = len(sub_df[(sub_df['button_pressed_conf'] == 3) & (
                    sub_df['response_cat'] == 'MISS') & (sub_df['choice_label'] == 'NO')])

                cr_very_uncertain = len(sub_df[(sub_df['button_pressed_conf'] == 0) & (
                    sub_df['response_cat'] == 'CR') & (sub_df['choice_label'] == 'NO')])
                cr_uncertain = len(sub_df[(sub_df['button_pressed_conf'] == 1) & (
                    sub_df['response_cat'] == 'CR') & (sub_df['choice_label'] == 'NO')])
                cr_certain = len(sub_df[(sub_df['button_pressed_conf'] == 2) & (
                    sub_df['response_cat'] == 'CR') & (sub_df['choice_label'] == 'NO')])
                cr_very_certain = len(sub_df[(sub_df['button_pressed_conf'] == 3) & (
                    sub_df['response_cat'] == 'CR') & (sub_df['choice_label'] == 'NO')])

                match += [hit_very_certain, hit_certain, hit_uncertain, hit_very_uncertain, fa_very_uncertain,
                          fa_uncertain, fa_certain, fa_very_certain]
                mismatch += [miss_very_certain, miss_certain, miss_uncertain, miss_very_uncertain, cr_very_uncertain,
                             cr_uncertain, cr_certain, cr_very_certain]

            output_table_complete.loc[sId + '-Match'] = match
            output_table_complete.loc[sId + '-Mismatch'] = mismatch

        print('Success.')
        return output_table_complete

    except Exception as e:
        print('Failed -> ', e)


def getCumsumPerStudentPerPhase(df):
    try:

        sdt_cumulFreqs = df.apply(np.cumsum, axis=1).T

        # for index, row in df.iterrows():
        #     sId = index.split('-')[0]
        #     choice = index.split('-')[1]

        #     if choice == 'No':
        #         continue

        #     # print(row[:-2])
        #     # temp = []

        #     # for i in range(totalPhase):  # No. of Phase
        #         # yes_series = row[i*8:(i+1)*8]

        #         # hit = yes_series[:4].sum()
        #         # fa = yes_series[4:].sum()

        #         # temp.append(yes_series)

        #     output_table_complete.loc[sId] = list(row[:-2])

        print('Success.')
        return sdt_cumulFreqs

    except Exception as e:
        print('Failed -> ', e)


def getMatchMismatchProportionPerStudentPerPhase(df):
    try:

        output_data_complete = {
            "1-4-Yes": [],
            "1-3-Yes": [],
            "1-2-Yes": [],
            "1-1-Yes": [],
            "1-1-No": [],
            "1-2-No": [],
            "1-3-No": [],
            "1-4-No": [],

            "2-4-Yes": [],
            "2-3-Yes": [],
            "2-2-Yes": [],
            "2-1-Yes": [],
            "2-1-No": [],
            "2-2-No": [],
            "2-3-No": [],
            "2-4-No": [],

            "3-4-Yes": [],
            "3-3-Yes": [],
            "3-2-Yes": [],
            "3-1-Yes": [],
            "3-1-No": [],
            "3-2-No": [],
            "3-3-No": [],
            "3-4-No": [],

            "4-4-Yes": [],
            "4-3-Yes": [],
            "4-2-Yes": [],
            "4-1-Yes": [],
            "4-1-No": [],
            "4-2-No": [],
            "4-3-No": [],
            "4-4-No": [],
        }

        sdt_cumulProps = pd.DataFrame(output_data_complete)

        for i in range(int(len(df.columns) / 2)):  # No of studnets
            nMatching = df.iloc[len(df) - 1, i * 2]
            nMismatching = df.iloc[len(df) - 1, (i * 2) + 1]

            sdt_cumulProps.loc[df.columns[i * 2]
                               ] = df.iloc[:, i * 2] / nMatching
            sdt_cumulProps.loc[df.columns[(
                i * 2) + 1]] = df.iloc[:, (i * 2) + 1] / nMismatching

        #         from scipy.stats import norm

        #         output_data_complete = {

        #             "1. FPR-1": [],
        #             "1. TPR-1": [],
        #             "1. d'-1": [],
        #             "1. FPR-2": [],
        #             "1. TPR-2": [],
        #             "1. d'-2": [],
        #             "1. FPR-3": [],
        #             "1. TPR-3": [],
        #             "1. d'-3": [],
        #             "1. FPR-4": [],
        #             "1. TPR-4": [],
        #             "1. d'-4": [],

        #             "2. FPR-1": [],
        #             "2. TPR-1": [],
        #             "2. d'-1": [],
        #             "2. FPR-2": [],
        #             "2. TPR-2": [],
        #             "2. d'-2": [],
        #             "2. FPR-3": [],
        #             "2. TPR-3": [],
        #             "2. d'-3": [],
        #             "2. FPR-4": [],
        #             "2. TPR-4": [],
        #             "2. d'-4": [],

        #             "3. FPR-1": [],
        #             "3. TPR-1": [],
        #             "3. d'-1": [],
        #             "3. FPR-2": [],
        #             "3. TPR-2": [],
        #             "3. d'-2": [],
        #             "3. FPR-3": [],
        #             "3. TPR-3": [],
        #             "3. d'-3": [],
        #             "3. FPR-4": [],
        #             "3. TPR-4": [],
        #             "3. d'-4": [],

        #             "4. FPR-1": [],
        #             "4. TPR-1": [],
        #             "4. d'-1": [],
        #             "4. FPR-2": [],
        #             "4. TPR-2": [],
        #             "4. d'-2": [],
        #             "4. FPR-3": [],
        #             "4. TPR-3": [],
        #             "4. d'-3": [],
        #             "4. FPR-4": [],
        #             "4. TPR-4": [],
        #             "4. d'-4": [],
        #         }

        #         output_table_complete = pd.DataFrame(output_data_complete)

        #         for index, row in df.iterrows():
        #             sId = index

        #             temp = []

        #             for i in range(totalPhase):  # No. of Phase
        #                 for j in range(4):  # No. of Ratings
        #                     hit = row[i*8+j]
        #                     fa = row[(i*8)+4+j]

        #                     fpr = fa/16
        #                     tpr = hit/16

        #                     d = norm.ppf(tpr) - norm.ppf(fpr)

        #                     if np.isnan(d) or d == float('inf') or d == float('-inf'):
        #                         fpr = (fa+0.5)/17
        #                         tpr = (hit+0.5)/17
        #                         d = norm.ppf(tpr) - norm.ppf(fpr)

        #                     temp.append(fpr)
        #                     temp.append(tpr)
        #                     temp.append(d)

        #             output_table_complete.loc[sId] = temp

        print('Success.')
        return sdt_cumulProps

    except Exception as e:
        print('Failed -> ', e)


def getHitFaPerPhasePerStudent(df, total_students):
    try:

        output_data_complete = {

            "0. Code": [],
            "1. Phase": [],
            "2. Hit-4-Yes": [],
            "3. Hit-3-Yes": [],
            "4, Hit-2-Yes": [],
            "5, Hit-1-Yes": [],
            "6, Hit-1-No": [],
            "7, Hit-2-No": [],
            "8, Hit-3-No": [],
            "9, Hit-4-No": [],
            "10. FA-4-Yes": [],
            "11. FA-3-Yes": [],
            "12, FA-2-Yes": [],
            "13, FA-1-Yes": [],
            "14, FA-1-No": [],
            "15, FA-2-No": [],
            "16, FA-3-No": [],
            "17, FA-4-No": [],

        }

        output_table_complete = pd.DataFrame(output_data_complete)

        for i in range(total_students):
            sId = df.iloc[i * 2].name.split('-')[0]
            for j in range(totalPhase):
                phase = j + 1
                temp = [sId, phase]

                temp += list(df.iloc[i * 2, j * 8:((j + 1) * 8)])
                temp += list(df.iloc[(i * 2) + 1, j * 8:((j + 1) * 8)])

                output_table_complete.loc[len(
                    output_table_complete) + 1] = temp

        print('Success.')
        return output_table_complete

    except Exception as e:
        print('Failed -> ', e)


def plotROCCurvePerPhasePerStudent(df, total_students):
    try:

        colors = {
            '1': 'y',
            '2': 'g',
            '3': 'b',
            '4': 'r',
        }

        for i in range(total_students):
            sId = df.iloc[i * 4, 0]
            for j in range(totalPhase):
                phase = j + 1

                plt.scatter(
                    list(df.iloc[(i * 4) + j, 9:]),
                    list(df.iloc[(i * 4) + j, 2:9]),
                    color=colors[str(phase)]
                )

                plt.plot(
                    list(df.iloc[(i * 4) + j, 9:]),
                    list(df.iloc[(i * 4) + j, 2:9]),
                    label="Phase " + str(phase),
                    color=colors[str(phase)],
                    linestyle='-.'
                )

            # plt.xlim(0, 1)
            # plt.ylim(0, 1)
            plt.plot([0, 1], [0, 1], label='Random Guessing', linestyle='--')
            plt.xlabel("False-alarm rate")
            plt.ylabel("Hit rate")
            plt.title(sId + " Hit Rate vs False-alarm Rate")
            plt.legend()
            plt.show()

        print('Success.')
        return df

    except Exception as e:
        print('Failed -> ', e)


def plotAggregatedROCPerPhase(df):
    try:

        output_data_complete = {

            "1. Phase": [],
            "2. Hit-4-Yes": [],
            "3. Hit-3-Yes": [],
            "4, Hit-2-Yes": [],
            "5, Hit-1-Yes": [],
            "6, Hit-1-No": [],
            "7, Hit-2-No": [],
            "8, Hit-3-No": [],
            "9, Hit-4-No": [],
            "10. FA-4-Yes": [],
            "11. FA-3-Yes": [],
            "12, FA-2-Yes": [],
            "13, FA-1-Yes": [],
            "14, FA-1-No": [],
            "15, FA-2-No": [],
            "16, FA-3-No": [],
            "17, FA-4-No": [],

        }

        output_table_complete = pd.DataFrame(output_data_complete)

        df.drop(['0. Code'], axis=1, inplace=True)

        for name, sub_df in df.groupby('1. Phase'):
            sub_df.drop(['1. Phase'], axis=1, inplace=True)

            mean = sub_df.mean()

            output_table_complete.loc[len(
                output_table_complete) + 1] = [name] + list(mean)

            x = list(mean[8:])
            y = list(mean[:8])

            plt.scatter(x, y)
            plt.plot(x, y, linestyle='-.', label='Phase ' + str(name))

            plt.plot([0, 1], [0, 1], label='Random Guessing', linestyle='--')
            plt.xlabel("False-alarm rate")
            plt.ylabel("Hit rate")
            plt.title("Hit Rate vs False-alarm Rate")
            plt.legend()
            plt.show()

        print('Success.')
        return output_table_complete

    except Exception as e:
        print('Failed -> ', e)


def plotMatchMismatchProportionPerPhasePerStudent(df, total_students):
    try:

        colors = {
            '1': 'y',
            '2': 'g',
            '3': 'b',
            '4': 'r',
        }

        for i in range(total_students):
            sId = df.index[i * 2].split('-')[0]
            for j in range(totalPhase):
                phase = j + 1

                plt.scatter(
                    list(df.iloc[(i * 2), (j * 8):((j + 1) * 8) - 1]),
                    list(df.iloc[(i * 2) + 1, (j * 8):((j + 1) * 8) - 1]),
                    color=colors[str(phase)]
                )

                plt.plot(
                    list(df.iloc[(i * 2), (j * 8):((j + 1) * 8) - 1]),
                    list(df.iloc[(i * 2) + 1, (j * 8):((j + 1) * 8) - 1]),
                    label="Phase " + str(phase),
                    color=colors[str(phase)],
                    linestyle='-.'
                )

            # plt.xlim(0, 1)
            # plt.ylim(0, 1)
            plt.plot([0, 1], [0, 1], label='Random Guessing', linestyle='--')
            plt.xlabel("False-alarm rate")
            plt.ylabel("Hit rate")
            plt.title(sId + " Hit Rate vs False-alarm Rate")
            plt.legend()
            plt.show()

        print('Success.')

    except Exception as e:
        print('Failed -> ', e)


def plotAggregatedMatchMismatchProportionPerPhaseForAllStudent(df):
    try:

        colors = {
            '1': 'y',
            '2': 'g',
            '3': 'b',
            '4': 'r',
        }

        output_data_complete = {
            "1-4-Yes": [],
            "1-3-Yes": [],
            "1-2-Yes": [],
            "1-1-Yes": [],
            "1-1-No": [],
            "1-2-No": [],
            "1-3-No": [],
            "1-4-No": [],

            "2-4-Yes": [],
            "2-3-Yes": [],
            "2-2-Yes": [],
            "2-1-Yes": [],
            "2-1-No": [],
            "2-2-No": [],
            "2-3-No": [],
            "2-4-No": [],

            "3-4-Yes": [],
            "3-3-Yes": [],
            "3-2-Yes": [],
            "3-1-Yes": [],
            "3-1-No": [],
            "3-2-No": [],
            "3-3-No": [],
            "3-4-No": [],

            "4-4-Yes": [],
            "4-3-Yes": [],
            "4-2-Yes": [],
            "4-1-Yes": [],
            "4-1-No": [],
            "4-2-No": [],
            "4-3-No": [],
            "4-4-No": [],
        }

        sdt_cumulProps_mean = pd.DataFrame(output_data_complete)

        df_match = df.iloc[::2]
        df_mismatch = df.iloc[1::2]

        df_match = df_match.mean()
        df_mismatch = df_mismatch.mean()

        sdt_cumulProps_mean.loc['Match'] = df_match
        sdt_cumulProps_mean.loc['Mismatch'] = df_mismatch

        for j in range(totalPhase):
            phase = j + 1

            plt.scatter(
                list(df_match[(j * 8):((j + 1) * 8) - 1]),
                list(df_mismatch[(j * 8):((j + 1) * 8) - 1]),
                color=colors[str(phase)]
            )

            plt.plot(
                list(df_match[(j * 8):((j + 1) * 8) - 1]),
                list(df_mismatch[(j * 8):((j + 1) * 8) - 1]),
                label="Phase " + str(phase),
                color=colors[str(phase)],
                linestyle='-.'
            )

        plt.plot([0, 1], [0, 1], label='Random Guessing', linestyle='--')
        plt.xlabel("False-alarm rate")
        plt.ylabel("Hit rate")
        plt.title("Hit Rate vs False-alarm Rate")
        plt.legend()
        plt.show()

        print('Success.')
        return sdt_cumulProps_mean

    except Exception as e:
        print('Failed -> ', e)
