import pandas as pd
from helper_roc import getQualifiedCandList, getMatchMisMatchFreqForEachStudentPerPhase, getCumsumPerStudentPerPhase, getMatchMismatchProportionPerStudentPerPhase,  getHitFaPerPhasePerStudent, plotROCCurvePerPhasePerStudent, plotAggregatedROCPerPhase, plotMatchMismatchProportionPerPhasePerStudent, plotAggregatedMatchMismatchProportionPerPhaseForAllStudent

dino_path = "/Users/abii/Documents/Data/Dino-II/"
qualified_cand_file = "/Users/abii/Documents/Data/qualified_cand.txt"

# pandas configurations
pd.options.display.float_format = "{:,.4f}".format
pd.set_option('display.width', 400)

print('Trying to get Qualified Candidates Ids w.r.t Dino.')
dino_files_list = getQualifiedCandList(1, qualified_cand_file)

print('Trying to calculate Match/MisMatch Trail Freq Per Phase For Each Student.')
df = getMatchMisMatchFreqForEachStudentPerPhase(dino_files_list, dino_path)
df.to_csv('./matchMismatchFreqPerPhaseForEachStudent.csv')

print('Trying to calculate cumsum Per Phase For Each Student.')
df = getCumsumPerStudentPerPhase(df)
df.to_csv('./cumsumPerPhaseForEachStudent.csv')

print('Trying to calculate Match/MisMatch Proportions Per Phase For Each Student.')
df = getMatchMismatchProportionPerStudentPerPhase(df)
df.to_csv('./matchMismatchProportionPerPhaseForEachStudent.csv')

print('Trying to calculate HIT/FA Per Phase For Each Student.')
df = getHitFaPerPhasePerStudent(df, len(dino_files_list))
df.to_csv('./hitfaPerPhasePerStudent.csv')

# print('Trying to plot ROC Curve Per Phase Per Student.')
# plotROCCurvePerPhasePerStudent(df, len(dino_files_list))

print("Trying to plot aggregated ROC Per Phase All Studnet.")
df = plotAggregatedROCPerPhase(df)
df.to_csv('./hitfaPerPhasePerStudentMean.csv')

# print("Trying to plot Match/Mismatch proportion Per Phase Per Studnet.")
# plotMatchMismatchProportionPerPhasePerStudent(df, len(dino_files_list))

# print("Trying to plot aggregated Match/Mismatch proportion Per Phase For All Studnet.")
# df = plotAggregatedMatchMismatchProportionPerPhaseForAllStudent(df)
# df.to_csv('./matchMismatchProportionPerPhase ForEachStudentMean.csv')