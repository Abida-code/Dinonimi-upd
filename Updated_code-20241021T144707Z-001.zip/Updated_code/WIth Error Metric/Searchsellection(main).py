import pandas as pd
from helper_searchselection import getQualifiedCandList, getPerPhaseSpecieSelectionWithPastFrequencyForEachStudent, getSummaryWRTPastFrequencyForAllStudent, aggregateDataIn10QuantileOfPastFrequencyMean,  plotResultsSRVSPastFreqWithLogisticRegression

sym_path = "/home/momin/abida_new_updated/Data/Symspan-II/"
dino_path = "/home/momin/abida_new_updated/Data/Dino-II/"
qualified_cand_file = "/home/momin/abida_new_updated/Data/qualified_cand.txt"
# pandas configurations
pd.options.display.float_format = "{:,.4f}".format
pd.set_option('display.width', 400)

print('Trying to get Qualified Candidates Ids w.r.t Dino.')
dino_files_list = getQualifiedCandList(1, qualified_cand_file)

print('Trying to get per phase specie selection with past frequency for each student. (It may take few minutes)')
df_complete = getPerPhaseSpecieSelectionWithPastFrequencyForEachStudent(
    dino_path, dino_files_list)
df_complete.to_csv(
    './getPerPhaseSpecieSelectionWithPastFrequencyForEachStudentComplete.csv')

df = pd.read_csv(
    './getPerPhaseSpecieSelectionWithPastFrequencyForEachStudentComplete.csv')
print('Trying to summarize w.r.t past frequency for all student.')
stats = getSummaryWRTPastFrequencyForAllStudent(df)
stats.to_csv('./pastFrequencyBasedSummary.csv')

stats = pd.read_csv('./pastFrequencyBasedSummary.csv')
print('Aggregate in 10 Bin WRT Past Frequency Mean')
df = aggregateDataIn10QuantileOfPastFrequencyMean(stats)
df.to_csv('./pastFrequency10BinDataMean.csv')

df = pd.read_csv('./pastFrequency10BinDataMean.csv')
print('Displaying Results Past Frequency 10 Bin vs S.R With Logistic Regression')
plotResultsSRVSPastFreqWithLogisticRegression(df)
