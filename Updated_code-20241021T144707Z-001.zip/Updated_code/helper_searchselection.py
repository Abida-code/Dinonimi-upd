import pandas as pd
import os
import matplotlib.pyplot as plt
import numpy as np

# Constants
trialsPerPhase = 10
totalPhase = 7
totalFamilies = 4
totalSpecies = 8

family_code = {
    "SAUROPODOMORPHA": 1,
    "STYRACOSTERNA": 2,
    "THEROPODA": 3,
    "ELASMARIA": 4
}

specie_code = {
    "ARGENTINOSAURUS": 1,
    "BARILIUM": 2,
    "CHARACHODONTOSAURUS": 3,
    "ISASICURSOR": 4,
    "MACROGRYPHOSAURUS": 5,
    "SATURNALIA": 6,
    "UTEODON": 7,
    "VELOCIRAPTOR": 8
}

colors = ['black', 'lime', 'aqua', 'red', 'purple',
          'green', 'pink', 'orange', 'yellow', 'blue']


def getQualifiedCandList(flag, qualified_cand_file):

    try:
        # flag 1 -> Dino 2 -> Sym

        file1 = open(qualified_cand_file, "r")

        cand = []

        postfix = ''

        if flag == 2:
            postfix = '-Symspan.txt'
        else:
            postfix = '-Dino.csv'

        for f in file1.readlines():
            name = f.split('\n')[0]
            name += postfix
            cand.append(name)

        file1.close()
        print('Success')
        return cand
    except:
        print('Failed')


def getPerPhaseSpecieSelectionWithPastFrequencyForEachStudent(dino_path, dino_files_list):

    try:
        output_data_complete = {
            "01. code": [],
            "02. phase": [],
            "03. round": [],
            "04. ARGENTINOSAURUS": [],
            "05. past_freq": [],
            "06. BARILIUM": [],
            "07. past_freq": [],
            "08. CHARACHODONTOSAURUS": [],
            "09. past_freq": [],
            "10. ISASICURSOR": [],
            "11. past_freq": [],
            "12. MACROGRYPHOSAURUS": [],
            "13. past_freq": [],
            "14. SATURNALIA": [],
            "15. past_freq": [],
            "16. UTEODON": [],
            "17. past_freq": [],
            "18. VELOCIRAPTOR": [],
            "19. past_freq": []
        }

        output_table_complete = pd.DataFrame(output_data_complete)

        for csv in dino_files_list:
            df = pd.read_csv(dino_path+csv)

            specie_selection_freq = {
                "ARGENTINOSAURUS": 0,
                "BARILIUM": 0,
                "CHARACHODONTOSAURUS": 0,
                "ISASICURSOR": 0,
                "MACROGRYPHOSAURUS": 0,
                "SATURNALIA": 0,
                "UTEODON": 0,
                "VELOCIRAPTOR": 0
            }

            sId = csv.split('-')[0]

            df = df[['species_selected']]
            df.dropna(inplace=True)
            df.reset_index(drop=True, inplace=True)

            # Convert String to uppercase
            df['species_selected'] = df['species_selected'].str.upper()

            for p in range(totalPhase):
                startIndex = p*trialsPerPhase
                endIndex = (p+1)*trialsPerPhase

                sub_df = df[startIndex:endIndex]
                sub_df.reset_index(drop=True, inplace=True)

                # Parameters
                phase = p+1

                for t in range(trialsPerPhase):

                    specie_current_selection = {
                        "ARGENTINOSAURUS": 0,
                        "BARILIUM": 0,
                        "CHARACHODONTOSAURUS": 0,
                        "ISASICURSOR": 0,
                        "MACROGRYPHOSAURUS": 0,
                        "SATURNALIA": 0,
                        "UTEODON": 0,
                        "VELOCIRAPTOR": 0
                    }

                    current_selection = sub_df.at[t, 'species_selected']

                    Round = t+1

                    if current_selection == 'ARGENTINOSAURUS':
                        specie_current_selection['ARGENTINOSAURUS'] = 1
                    elif current_selection == 'BARILIUM':
                        specie_current_selection['BARILIUM'] = 1
                    elif current_selection == 'CHARACHODONTOSAURUS':
                        specie_current_selection['CHARACHODONTOSAURUS'] = 1
                    elif current_selection == 'ISASICURSOR':
                        specie_current_selection['ISASICURSOR'] = 1
                    elif current_selection == 'MACROGRYPHOSAURUS':
                        specie_current_selection['MACROGRYPHOSAURUS'] = 1
                    elif current_selection == 'SATURNALIA':
                        specie_current_selection['SATURNALIA'] = 1
                    elif current_selection == 'UTEODON':
                        specie_current_selection['UTEODON'] = 1
                    elif current_selection == 'VELOCIRAPTOR':
                        specie_current_selection['VELOCIRAPTOR'] = 1

                    output_table_complete.loc[len(output_table_complete.index)] = [sId, phase, Round, specie_current_selection['ARGENTINOSAURUS'], specie_selection_freq['ARGENTINOSAURUS'], specie_current_selection['BARILIUM'], specie_selection_freq['BARILIUM'], specie_current_selection['CHARACHODONTOSAURUS'], specie_selection_freq['CHARACHODONTOSAURUS'], specie_current_selection['ISASICURSOR'],
                                                                                   specie_selection_freq['ISASICURSOR'], specie_current_selection['MACROGRYPHOSAURUS'], specie_selection_freq['MACROGRYPHOSAURUS'], specie_current_selection['SATURNALIA'], specie_selection_freq['SATURNALIA'], specie_current_selection['UTEODON'], specie_selection_freq['UTEODON'], specie_current_selection['VELOCIRAPTOR'], specie_selection_freq['VELOCIRAPTOR']]

                    # update frequecies
                    specie_selection_freq[current_selection] += 1

        print('Success.')
        return output_table_complete
    except:
        print('Failed')


def getSummaryWRTPastFrequencyForAllStudent(df):

    try:

        past_freq_stats_data = {
            "1. past_freq": [],
            "2. 0's": [],
            "3. 1's": [],
            "4. S.R": []
        }

        past_freq_stats_table = pd.DataFrame(past_freq_stats_data)

        students_data = {}

        past_specie_1 = df.groupby('05. past_freq')

        for freq, specie_1_df in past_specie_1:
            specie_1_df.reset_index(drop=True, inplace=True)

            zeros = len(specie_1_df[specie_1_df['04. ARGENTINOSAURUS'] == 0])
            ones = len(specie_1_df[specie_1_df['04. ARGENTINOSAURUS'] == 1])

            if freq in students_data:
                students_data[freq]['zeros'] += zeros
                students_data[freq]['ones'] += ones
            else:
                students_data[freq] = {
                    "zeros": zeros,
                    "ones": ones
                }

        past_specie_2 = df.groupby('07. past_freq')

        for freq, specie_2_df in past_specie_2:
            specie_2_df.reset_index(drop=True, inplace=True)

            zeros = len(specie_2_df[specie_2_df['06. BARILIUM'] == 0])
            ones = len(specie_2_df[specie_2_df['06. BARILIUM'] == 1])

            if freq in students_data:
                students_data[freq]['zeros'] += zeros
                students_data[freq]['ones'] += ones
            else:
                students_data[freq] = {
                    "zeros": zeros,
                    "ones": ones
                }

        past_specie_3 = df.groupby('09. past_freq')

        for freq, specie_3_df in past_specie_3:
            specie_3_df.reset_index(drop=True, inplace=True)

            zeros = len(
                specie_3_df[specie_3_df['08. CHARACHODONTOSAURUS'] == 0])
            ones = len(
                specie_3_df[specie_3_df['08. CHARACHODONTOSAURUS'] == 1])

            if freq in students_data:
                students_data[freq]['zeros'] += zeros
                students_data[freq]['ones'] += ones
            else:
                students_data[freq] = {
                    "zeros": zeros,
                    "ones": ones
                }

        past_specie_4 = df.groupby('11. past_freq')

        for freq, specie_4_df in past_specie_4:
            specie_4_df.reset_index(drop=True, inplace=True)

            zeros = len(specie_4_df[specie_4_df['10. ISASICURSOR'] == 0])
            ones = len(specie_4_df[specie_4_df['10. ISASICURSOR'] == 1])

            if freq in students_data:
                students_data[freq]['zeros'] += zeros
                students_data[freq]['ones'] += ones
            else:
                students_data[freq] = {
                    "zeros": zeros,
                    "ones": ones
                }

        past_specie_5 = df.groupby('13. past_freq')

        for freq, specie_5_df in past_specie_5:
            specie_5_df.reset_index(drop=True, inplace=True)

            zeros = len(specie_5_df[specie_5_df['12. MACROGRYPHOSAURUS'] == 0])
            ones = len(specie_5_df[specie_5_df['12. MACROGRYPHOSAURUS'] == 1])

            if freq in students_data:
                students_data[freq]['zeros'] += zeros
                students_data[freq]['ones'] += ones
            else:
                students_data[freq] = {
                    "zeros": zeros,
                    "ones": ones
                }

        past_specie_6 = df.groupby('15. past_freq')

        for freq, specie_6_df in past_specie_6:
            specie_6_df.reset_index(drop=True, inplace=True)

            zeros = len(specie_6_df[specie_6_df['14. SATURNALIA'] == 0])
            ones = len(specie_6_df[specie_6_df['14. SATURNALIA'] == 1])

            if freq in students_data:
                students_data[freq]['zeros'] += zeros
                students_data[freq]['ones'] += ones
            else:
                students_data[freq] = {
                    "zeros": zeros,
                    "ones": ones
                }

        past_specie_7 = df.groupby('17. past_freq')

        for freq, specie_7_df in past_specie_7:
            specie_7_df.reset_index(drop=True, inplace=True)

            zeros = len(specie_7_df[specie_7_df['16. UTEODON'] == 0])
            ones = len(specie_7_df[specie_7_df['16. UTEODON'] == 1])

            if freq in students_data:
                students_data[freq]['zeros'] += zeros
                students_data[freq]['ones'] += ones
            else:
                students_data[freq] = {
                    "zeros": zeros,
                    "ones": ones
                }

        past_specie_8 = df.groupby('19. past_freq')

        for freq, specie_8_df in past_specie_8:
            specie_8_df.reset_index(drop=True, inplace=True)

            zeros = len(specie_8_df[specie_8_df['18. VELOCIRAPTOR'] == 0])
            ones = len(specie_8_df[specie_8_df['18. VELOCIRAPTOR'] == 1])

            if freq in students_data:
                students_data[freq]['zeros'] += zeros
                students_data[freq]['ones'] += ones
            else:
                students_data[freq] = {
                    "zeros": zeros,
                    "ones": ones
                }

        for key in students_data.keys():

            zeros = students_data[key]['zeros']
            ones = students_data[key]['ones']
            rate = ones / (zeros+ones)

            past_freq_stats_table.loc[len(past_freq_stats_table.index)] = [
                key, zeros, ones, rate]

        print('Success')
        return past_freq_stats_table
    except Exception as e:
        print('Failed', e)


def aggregateDataIn10QuantileOfPastFrequencyMean(df):
    try:

        past_freq_stats_data = {
            "1. bin": [],
            "2. S.R Mean": [],
            "3. S.R Var": [],
            "4. S.R SD": []
        }

        past_freq_stats_table = pd.DataFrame(past_freq_stats_data)

        df['5. bin'], cut_bin = pd.qcut(df['1. past_freq'], q=10, labels=[
                                        '1', '2', '3', '4', '5', '6', '7', '8', '9', '10'], retbins=True)

        bins = df.groupby('5. bin')

        for name, bin_df in bins:
            mean = bin_df['4. S.R'].mean()
            var = bin_df['4. S.R'].var(ddof=0)
            std = bin_df['4. S.R'].std(ddof=0)
            past_freq_stats_table.loc[len(past_freq_stats_table.index)] = [
                name, mean, var, std]

        print('Success')
        return past_freq_stats_table
    except Exception as e:
        print('Failed', e)

# def sigmoid(arr, th):
# 	try:
# 		temp = []
# 		for n in arr:
# 			if n > th:
# 				temp.append(1)
# 			else:
# 				temp.append(0)
# 		return np.array(temp)

# 	except:
# 		print('Failed')


def plotResultsSRVSPastFreqWithLogisticRegression(df):

    try:

        # from sklearn import linear_model
        from scipy.optimize import curve_fit

        # Reshaped for Logistic function.
        xdata = np.array(df['1. bin'])
        ydata = np.array(df['2. S.R Mean'])
        yerr = np.array(df['3. S.R Var'])

        def sigmoid(x, L, x0, k, b):

            y = L / (1 + np.exp(-k*(x-x0))) + b
            return (y)

        def linear_fn(x, m, c):
            return m*x+c

        def hill_fn(x, n, K):
            return (x**n) / (x**n + K**n)

        def gompertz_fn(x, a, b, c):
            return a*np.exp(-b*np.exp(-c*x))

        # this is an mandatory initial guess
        p0_linear = [1, 0]
        p0_sigmoid = [max(ydata), np.median(xdata), 1, min(ydata)]
        p0_gompertz = [max(ydata), max(ydata), max(ydata)]
        p0_hill = [max(ydata), 1]

        popt_l, pcov_l = curve_fit(
            linear_fn, xdata, ydata, p0_linear, maxfev=10000, method='trf')
        popt_s, pcov_s = curve_fit(
            sigmoid, xdata, ydata, p0_sigmoid, maxfev=10000, method='trf')
        popt_g, pcov_g = curve_fit(
            gompertz_fn, xdata, ydata, p0_gompertz, maxfev=10000, method='trf')
        popt_h, pcov_h = curve_fit(
            hill_fn, xdata, ydata, p0_hill, maxfev=10000, method='trf')

        print(popt_l)
        print(popt_s)
        print(popt_g)
        print(popt_h)

        y_l = linear_fn(xdata, *popt_l)
        y_s = sigmoid(xdata, *popt_s)
        y_g = gompertz_fn(xdata, *popt_g)
        y_h = hill_fn(xdata, *popt_h)

        diff = np.square(y_h - ydata)

        plt.plot(xdata, y_l, label='Model')
        plt.errorbar(xdata, y_l, xerr=None, yerr=diff, linewidth=2.5,
                     fmt='None', ecolor='red', label='Error Model')
        plt.errorbar(xdata, ydata, xerr=None, yerr=yerr, linewidth=2.5,
                     fmt='None', ecolor='black', label='Variance Data')
        plt.scatter(data=df, x='1. bin', y='2. S.R Mean',
                    color='blue', label='Data')

        plt.legend(loc="upper left", ncol=2, fontsize=10)
        plt.xlabel("Past Frequency Bin")
        plt.ylabel("Selection Rate Mean")
        plt.title("Linear Model")

        plt.show()

        plt.plot(xdata, y_s, label='Model')
        plt.errorbar(xdata, y_s, xerr=None, yerr=diff, linewidth=2.5,
                     fmt='None', ecolor='red', label='Error Model')
        plt.errorbar(xdata, ydata, xerr=None, yerr=yerr, linewidth=2.5,
                     fmt='None', ecolor='black', label='Variance Data')
        plt.scatter(data=df, x='1. bin', y='2. S.R Mean',
                    color='blue', label='Data')

        plt.legend(loc="upper left", ncol=2, fontsize=10)
        plt.xlabel("Past Frequency Bin")
        plt.ylabel("Selection Rate Mean")
        plt.title("Sigmoid Model")

        plt.show()

        plt.plot(xdata, y_g, label='Model')
        plt.errorbar(xdata, y_g, xerr=None, yerr=diff, linewidth=2.5,
                     fmt='None', ecolor='red', label='Error Model')
        plt.errorbar(xdata, ydata, xerr=None, yerr=yerr, linewidth=2.5,
                     fmt='None', ecolor='black', label='Variance Data')
        plt.scatter(data=df, x='1. bin', y='2. S.R Mean',
                    color='blue', label='Data')

        plt.legend(loc="upper left", ncol=2, fontsize=10)
        plt.xlabel("Past Frequency Bin")
        plt.ylabel("Selection Rate Mean")
        plt.title("Gompertz Model")

        plt.show()

        plt.plot(xdata, y_h, label='Model')
        plt.errorbar(xdata, y_h, xerr=None, yerr=diff, linewidth=2.5,
                     fmt='None', ecolor='red', label='Error Model')
        plt.errorbar(xdata, ydata, xerr=None, yerr=yerr, linewidth=2.5,
                     fmt='None', ecolor='black', label='Variance Data')
        plt.scatter(data=df, x='1. bin', y='2. S.R Mean',
                    color='blue', label='Data')

        plt.legend(loc="upper left", ncol=2, fontsize=10)
        plt.xlabel("Past Frequency Bin")
        plt.ylabel("Selection Rate Mean")
        plt.title("Hill Model")

        plt.show()
        print('Success')
    except Exception as e:
        print('Failed', e)
